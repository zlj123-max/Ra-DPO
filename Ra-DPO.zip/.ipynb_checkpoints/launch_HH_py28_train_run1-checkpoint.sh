# ##########################################################
# Our Risk-TDPO-2 alpha=0.9     to do
# ##########################################################
# SFT-Risk-TDPO-2 Loss(alpha=0.9, confidence_level=0.99):
CUDA_VISIBLE_DEVICES=0 accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29500 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py28_sft_rtdpo2_alp0.9_cl0.99 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-2.8b ++model.load_from=.cache/EleutherAI/pythia-2_8b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.9 ++loss.confidence_level=0.99 


# SFT-Risk-TDPO-2 Loss(alpha=0.9, confidence_level=0.98):
CUDA_VISIBLE_DEVICES=0 accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29500 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py28_sft_rtdpo2_alp0.9_cl0.98 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-2.8b ++model.load_from=.cache/EleutherAI/pythia-2_8b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.9 ++loss.confidence_level=0.98 


# SFT-Risk-TDPO-2 Loss(alpha=0.9, confidence_level=0.97):
CUDA_VISIBLE_DEVICES=0 accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29500 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py28_sft_rtdpo2_alp0.9_cl0.97 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-2.8b ++model.load_from=.cache/EleutherAI/pythia-2_8b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.9 ++loss.confidence_level=0.97 


