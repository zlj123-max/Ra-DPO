#!/bin/bash

# SFT-Risk-TDPO-2 Loss(alpha=0.3, confidence_level=0.99):
accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29500 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py14_sft_rtdpo2_alp0.3_cl0.99 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-1.4b ++model.load_from=.cache/EleutherAI/pythia-1_4b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.3 ++loss.confidence_level=0.99 

# SFT-Risk-TDPO-2 Loss(alpha=0.3, confidence_level=0.98):
accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29501 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py14_sft_rtdpo2_alp0.3_cl0.98 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-1.4b ++model.load_from=.cache/EleutherAI/pythia-1_4b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.3 ++loss.confidence_level=0.98 

# SFT-Risk-TDPO-2 Loss(alpha=0.3, confidence_level=0.97):
accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29502 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py14_sft_rtdpo2_alp0.3_cl0.97 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-1.4b ++model.load_from=.cache/EleutherAI/pythia-1_4b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.3 ++loss.confidence_level=0.97 

# # SFT-Risk-TDPO-2 Loss(alpha=0.3, confidence_level=0.95):
# accelerate launch --config_file accelerate_config/fsdp_1gpu.yaml --main_process_port 29503 launch.py loss=rtdpo model=pythia datasets=[hh] exp_name=HH_py14_sft_rtdpo2_alp0.3_cl0.95 run_count=run1 ++model.name_or_path=HH_pretrained_model/EleutherAI/pythia-1.4b ++model.load_from=.cache/EleutherAI/pythia-1_4b_sft/run1/FINAL  ++loss.if_rtdpo2=true  ++loss.alpha=0.3 ++loss.confidence_level=0.95 

